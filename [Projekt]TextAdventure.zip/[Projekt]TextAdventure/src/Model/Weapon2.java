package Model;

public class Weapon2 extends Weapon {

    public Weapon2(){
        this.name = "Küchenmesser";
        this.level = 2;
        this.attack = 10;
    }
}
