package Model;

public class Cocumber extends Creature {

    public Cocumber(){

    }
}
