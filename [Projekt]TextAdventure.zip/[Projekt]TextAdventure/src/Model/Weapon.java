package Model;

public abstract class Weapon {

    String name;
    int level;
    int attack;

    public String getName() {
        return name;
    }
    public int getLevel() {
        return level;
    }
    public int getAttack() {
        return attack;
    }
}
