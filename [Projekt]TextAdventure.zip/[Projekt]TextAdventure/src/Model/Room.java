package Model;

public class Room{
    private int doors;
    private boolean monster;
    private boolean treasure;
    private int connectedWith1;
    private int connectedWith2;
    private int connectedWith3;
    private String info;
    private boolean wasOpened;
    private boolean treasureOpened;

    public Room(int doors, boolean monster, boolean treasure, int connectedWith1, int connectedWith2, int connectedWith3, String info,boolean wasOpened, boolean treasureOpened){
        this.doors = doors;
        this.monster = monster;
        this.treasure = treasure;
        this.connectedWith1 = connectedWith1;
        this.connectedWith2 = connectedWith2;
        this.connectedWith3 = connectedWith3;
        this.info = info;
        this.wasOpened = wasOpened;
        this.treasureOpened = treasureOpened;
    }

    public int getConnectedWith1()
    {
        return connectedWith1;
    }

    public int getConnectedWith2()
    {
        return connectedWith2;
    }

    public int getConnectedWith3()
    {
        return connectedWith3;
    }

    public int getDoors(){
        return doors;
    }

    public boolean getMonster(){
        return monster;
    }

    public boolean getTreasure(){
        return treasure;
    }

    public String getInfo(){
        return info;
    }

    public boolean getWasOpened(){
        return wasOpened;
    }

    public void setWasOpened(boolean opened){
        wasOpened = opened;
    }

    public boolean getTreasureOpened(){
        return treasureOpened;
    }

    public void setTreasureOpened(boolean opened){
        treasureOpened = opened;
    }
}
