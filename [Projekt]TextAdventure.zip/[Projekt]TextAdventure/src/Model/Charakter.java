package Model;


public class Charakter extends Creature {

    private int xp = 0;
    private Weapon currentWeapon;



    public Charakter(Weapon currentWeapon){
        this.name = "Seegurke-san";
        this.level = 1;
        this.livepoints = 10;
        this.strength = (int)(Math.random() * 4) + 8;
        this.defense = (int)(Math.random() * 4) + 8;
        this.currentWeapon = currentWeapon;

    }

    public void setXp(int xp){
        this.xp = xp;
    }

    public void setCurrentWeapon(Weapon newWeapon){
        currentWeapon = newWeapon;
    }


}
