package Model;

import Controller.MainController;

public class World {
    public Room[] allRooms = new Room[12];
//    private MainController controller = new MainController();

    public World() {


    }

    public void addRoom1(int doors, boolean monster, boolean treasure, int connectedWith1, int connectedWith2, int connectedWith3, String info, boolean wasOpened, boolean treasureOpened){
        Room[] newAllRooms = new Room[allRooms.length+1];
        for (int i = 0; i < allRooms.length; i++) {
            newAllRooms[i] = allRooms[i];
        }
        newAllRooms[allRooms.length] = new Room(doors, monster, treasure, connectedWith1, connectedWith2, connectedWith3, info, wasOpened, treasureOpened);
        allRooms = newAllRooms;
    }

    public void addRoom2(int aNumber,int doors, boolean monster, boolean treasure, int connectedWith1, int connectedWith2, int connectedWith3, String info, boolean wasOpened, boolean treasureOpened){
        allRooms[aNumber] = new Room(doors, monster, treasure, connectedWith1, connectedWith2, connectedWith3, info, wasOpened, treasureOpened);
    }

    public int currentRoom(int connectNumber, int roomNumber){
        if(connectNumber == 1){
            return allRooms[roomNumber].getConnectedWith1();
        }else if(connectNumber == 2){
            return allRooms[roomNumber].getConnectedWith2();
        }else{
            return allRooms[roomNumber].getConnectedWith3();
        }

    }

    public String[] getText(int currentRoom){
        String[] output = new String[6];
        output[0] = ""+allRooms[currentRoom].getDoors();
        output[1] = ""+allRooms[currentRoom].getMonster();
        output[2] = ""+allRooms[currentRoom].getTreasure();
        output[3] = ""+allRooms[currentRoom].getInfo();
        output[4] = ""+allRooms[currentRoom].getWasOpened();
        output[5] = ""+allRooms[currentRoom].getTreasureOpened();
        return output;
    }

    public void changeWasOpened(int currentRoom){
        allRooms[currentRoom].setWasOpened(true);
    }

    public void changeTreasureOpened(int currentRoom){
        allRooms[currentRoom].setTreasureOpened(true);
    }
}
