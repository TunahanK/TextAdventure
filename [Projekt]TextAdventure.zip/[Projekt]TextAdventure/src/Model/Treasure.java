package Model;

/**
 * Created by Max on 23.09.2016.
 */
public class Treasure {

    public Treasure(){

    }

    public int generateContent(){
        return (int)(Math.random()*3);
    }


}
