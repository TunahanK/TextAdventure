package Model;

public class Weapon3 extends Weapon {

    public Weapon3(){
        this.name = "Der heilige Gurkenschäler";
        this.level = 5;
        this.attack = 50;
    }
}
