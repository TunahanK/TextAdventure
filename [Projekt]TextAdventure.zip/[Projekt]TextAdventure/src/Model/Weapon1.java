package Model;

public class Weapon1 extends Weapon{

    public Weapon1(){
        this.name = "Zahnstocher";
        this.level = 1;
        this.attack = 5;
    }
}
