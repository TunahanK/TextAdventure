package View;

import Controller.MainController;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class View1 extends JFrame implements View{
    private JPanel MainPanel;
    private JButton vorwärtsButton;
    private JButton angriffButton;
    private JButton linksButton;
    private JButton rechtsButton;
    private JButton zurückButton;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JButton interagierenButton;
    private JButton ausruestenButton;
    private MainController controller;


    public View1(MainController controller){
        super("The Legend of the heilige Seegurke");
        this.controller = controller;
        setContentPane(MainPanel);
        pack();
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        updateTheGUI();
        this.changeTextArea1("Du befindest dich direkt vor dem Eingang des Gurkenboss." + "\n" + "Deine Aufgabe, den Gurkenboss zu töten, hast du fast geschaft."+ "\n" +"Du musst nur noch seine Handlanger in jedem Raum töten um an den Schlüssel zu kommen."+"\n" + "Viel Glück"+ "\n" + controller.doTheTextThing2());
        pack();


        rechtsButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                controller.changeRoomRight();
                updateTheGUI();
            }
        });



        linksButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                controller.changeRoomLeft();
                updateTheGUI();
            }
        });

        zurückButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                controller.changeRoomFrontOrBack();
                updateTheGUI();
            }
        });

       // if(controller.treasureFound) {
            interagierenButton.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    changeTextArea1("Waffe Gefunden: " + controller.openTreasure() + "\n" + "Ausrüsten?");
                }
            });
        //}else{
          // interagierenButton.setEnabled(false);
        //}

        if(controller.attackMode) {
            angriffButton.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {

                }
            });
        }else{
            angriffButton.setEnabled(false);
        }

        vorwärtsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.changeRoomFrontOrBack();
                updateTheGUI();
            }
        });

        //if(controller.treasureFound == true) {
          //  ausruestenButton.setEnabled(true);

            ausruestenButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    controller.takeWeapon();
                    controller.setTreasure(false);
                    changeTextArea1("Waffe Ausgerüstet!");
                }
            });
       // }else{
         //   ausruestenButton.setEnabled(false);
       // }
    }

    private void changeTextArea1(String text){
        textArea1.setText(text);
    }

    private void changeTextArea2(String text){
        textArea2.setText(text);
    }

    public void printText(String text){
        changeTextArea1(text);
    }

    private void updateTheGUI(){
        changeTextArea2(controller.doTheTextThing1());
        changeTextArea1(controller.doTheTextThing2());
        pack();
    }
}
