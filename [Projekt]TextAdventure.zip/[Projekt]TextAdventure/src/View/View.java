package View;

/**
 * Created by 204g10 on 23.09.2016.
 */
public interface View {

    public void printText(String text);
}
