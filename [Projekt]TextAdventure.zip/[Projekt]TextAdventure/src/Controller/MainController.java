package Controller;
import Model.Weapon1;
import Model.*;


public class MainController{



    private Treasure theTreasure = new Treasure();
    private Weapon1 toothpick = new Weapon1();
    private Weapon2 kitchenknife = new Weapon2();
    private Weapon3 theHolyCocumber = new Weapon3();
    private Charakter myCharacter = new Charakter(toothpick);
    private World myWorld = new World();

    private int randomWeapon;
    private int playerLocation = 0;
    boolean treasure;
    public boolean attackMode = false;
    public boolean treasureFound;

    public MainController(){
        myWorld.addRoom2(0,3,false,true,6,11,1,"Start Raum", true, false);
        myWorld.addRoom2(1,2,monsterOrTreasure(),treasureFound(),2,0,0,"Normaler Raum 1", false, false);
        myWorld.addRoom2(2,3,monsterOrTreasure(),treasureFound(),3,7,1,"Normaler Raum 2", false, false);
        myWorld.addRoom2(3,2,monsterOrTreasure(),treasureFound(),4,2,4,"Normaler Raum 3", false, false);
        myWorld.addRoom2(4,2,monsterOrTreasure(),treasureFound(),5,3,3,"Normaler Raum 4", false, false);
        myWorld.addRoom2(5,3,monsterOrTreasure(),treasureFound(),6,9,4,"Normaler Raum 5", false, false);
        myWorld.addRoom2(6,2,monsterOrTreasure(),treasureFound(),0,0,5,"Normaler Raum 6", false, false);
        myWorld.addRoom2(7,2,monsterOrTreasure(),treasureFound(),8,2,2,"Normaler Raum 7", false, false);
        myWorld.addRoom2(8,3,monsterOrTreasure(),treasureFound(),9,10,7,"Normaler Raum 8", false, false);
        myWorld.addRoom2(9,2,monsterOrTreasure(),treasureFound(),5,5,8,"Normaler Raum 9", false, false);
        myWorld.addRoom2(10,1,true,true,8,8,8,"Schlüssel Raum", false, false);
        myWorld.addRoom2(11,1,false,true,0,0,0,"Boss Raum", false, false);
    }



    public void changeRoomFrontOrBack(){
        myWorld.changeWasOpened(playerLocation);
        playerLocation = myWorld.currentRoom(2,playerLocation);
        treasureFound = myWorld.allRooms[playerLocation].getTreasure();
    }

    public void changeRoomLeft(){
        myWorld.changeWasOpened(playerLocation);
        playerLocation = myWorld.currentRoom(1,playerLocation);
        treasureFound = myWorld.allRooms[playerLocation].getTreasure();
    }

    public void changeRoomRight(){
        myWorld.changeWasOpened(playerLocation);
        playerLocation = myWorld.currentRoom(3,playerLocation);
        treasureFound = myWorld.allRooms[playerLocation].getTreasure();
    }

    public String doTheTextThing1(){
        String[] output = myWorld.getText(playerLocation);
        return "Anzahl der Türen: " + output[0] +  "\n" + output[3] + "\n" + "Raum schon entdeckt: " + output[4];
    }

    public String doTheTextThing2(){
        String[] output = myWorld.getText(playerLocation);
        return "Monster Vorhanden: " + output[1] + "\n" + "Truhe vorhanden: " + output[5];
    }

    private boolean monsterOrTreasure(){
        int z = (int)(Math.random()*2);
        if(z == 0){
            treasure = false;
            return true;
        }else {
            treasure = true;
            return false;
        }
    }

    private boolean treasureFound(){
        if(treasure = true){
            return true;
        }else{
            return false;
        }
    }

    public String openTreasure(){
        myWorld.changeTreasureOpened(playerLocation);
        randomWeapon = theTreasure.generateContent();
        if(randomWeapon == 0){
            return toothpick.getName();
        }else if(randomWeapon == 1){
            return kitchenknife.getName();
        }else{
            return theHolyCocumber.getName();
        }

    }

    public void takeWeapon(){
        if(randomWeapon == 1){
            myCharacter.setCurrentWeapon(toothpick);
        }else if(randomWeapon == 2){
            myCharacter.setCurrentWeapon(kitchenknife);
        }else {
            myCharacter.setCurrentWeapon(theHolyCocumber);
        }
    }

    public void setTreasure(boolean opened){
        myWorld.allRooms[playerLocation].setTreasureOpened(opened);
    }
}
